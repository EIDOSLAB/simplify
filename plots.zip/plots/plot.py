import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

archs = ['vgg', 'resnet']
df = pd.read_csv('times.csv')
print(df)

columns = df.columns
sel_columns = []

for col in columns:
    if not 'simplified' in col:
        continue
    
    if '__' in col:
        continue
    
    a = False
    for arch in archs:
        if arch in col:
            a = True
    
    if not a:
        continue

    sel_columns.append(col)

df = df[sel_columns]
print(df)


models = []
for col in sel_columns:
    models.append(col.replace('arch: ', '').replace(' - simplified.forward', '').replace(' - simplified.backward', ''))

models = sorted(list(set(models)))
models = ['resnet18', 'resnet34', 'resnet50', 'resnet101', 'resnet152', 'vgg11', 'vgg11_bn', 'vgg13', 'vgg13_bn', 'vgg16', 'vgg16_bn', 'vgg19', 'vgg19_bn']

print(models)
xticks = [] #np.linspace(0, 1, int(1./0.05))
p = 0
for i in range(20):
    xticks.append(p)
    p += 5

SMALL_SIZE = 24
MEDIUM_SIZE = 26
BIGGER_SIZE = 28


from matplotlib import rc
rc('axes', titlesize=18)     # fontsize of the axes title
rc('axes', labelsize=18)    # fontsize of the x and y labels
rc('xtick', labelsize=18)    # fontsize of the tick labels
rc('ytick', labelsize=18)    # fontsize of the tick labels
rc('legend', fontsize=14)    # legend fontsize
rc('figure', titlesize=BIGGER_SIZE)  # fontsize of the figure title
rc('font', size=18)
#rc('font', family='Times New Roman')
#rc('text', usetex=True)


fig = plt.figure(figsize=(10,8))
ax = fig.add_subplot(111)

maps = [
    plt.cm.Blues,
    plt.cm.Greens,
]

from itertools import cycle
lines = ["-","--","-.",":"]
linecycler = cycle(lines)

palettes = [
    cycle(["#D431F5", "#4F4CFC", "#51C3E6", "#4CFC93", "#B3F564"]),
    cycle(["#ADF52F", "#FCD949", "#E6964F", "#FC4F49", "#D662F5"])
]

for idx, arch in enumerate(archs):
    ax.set_prop_cycle('color', [maps[idx](i) for i in np.linspace(0.5, 1, 10)])

    print(arch)
    for model in models:
        if arch not in model:
            continue
        
        if 'vgg' in model and '_bn' not in model:
            continue
        print(model)
        
        forward_t = df[f'arch: {model} - simplified.forward']
        backward_t = df[f'arch: {model} - simplified.backward']
        time = forward_t + backward_t

        start_t = time[0]
        time = [((100.*t)/start_t) for t in time]

        label = model.replace('resnet', 'ResNet-').replace('vgg', 'VGG-').replace('_bn', '')
        ax.plot(xticks, time, label=label, linestyle=next(linecycler))

ax.set_xlabel('Pruned Neurons (%)')
ax.set_ylabel('Forward-Backward Time (%)')
ax.set_xlim(0, 95)
xticks = [] #np.linspace(0, 1, int(1./0.05))
p = 5
for i in range(10):
    xticks.append(p)
    p += 10
ax.set_xticks(xticks)
ax.set_xticklabels(xticks)
ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.legend()
plt.savefig('times.pdf', format='pdf', dpi=300, bbox_inches='tight', pad_inches=0)
plt.show()

exit(0)
import matplotlib.ticker as ticker

labels = []
times = []

for idx, arch in enumerate(archs):
    for model in models:
        if arch not in model:
            continue
        
        if 'vgg' in model and '_bn' not in model:
            continue
        
        forward_t = df[f'arch: {model} - simplified.forward']
        backward_t = df[f'arch: {model} - simplified.backward']
        time = forward_t + backward_t

        start_t = time[0]
        time = [((100.*t)/start_t) for t in time]
        label = model.replace('resnet', 'ResNet-').replace('vgg', 'VGG-').replace('_bn', '')

        times.append(time)
        labels.append(label)


#vectors to plot: 4D for this example
#y1=[1,2.3,8.0,2.5]
#y2=[1.5,1.7,2.2,2.9]
xticks = []
p = 0
for i in range(20):
    xticks.append(p)
    p += 5

y1 = times[0]
y2 = times[1]

x=xticks # spines

fig, axes = plt.subplots(1, 20, sharey=False)

# plot the same on all the subplots
#ax.plot(x, y1,'r-', x, y2, 'b-')
#ax2.plot(x, y1,'r-', x, y2, 'b-')
#ax3.plot(x, y1,'r-', x, y2, 'b-')
for ax in axes:
    ax.plot(x, y1,'r-', x, y2, 'b-')


# now zoom in each of the subplots 
for idx in range(len(x)-1):
    axes[idx].set_xlim([x[idx], x[idx+1]])
#ax.set_xlim([x[0], x[1]])
#ax2.set_xlim([x[1], x[2]])
#ax3.set_xlim([x[2], x[3]])

# set the x axis ticks 
for axx,xx in zip(axes, x[:-1]):
  axx.xaxis.set_major_locator(ticker.FixedLocator([xx]))
axes[-1].xaxis.set_major_locator(ticker.FixedLocator([x[-2],x[-1]]))  # the last one

# EDIT: add the labels to the rightmost spine
for tick in axes[-1].yaxis.get_major_ticks():
  tick.label2On=True

# stack the subplots together
plt.subplots_adjust(wspace=0)
plt.show()
